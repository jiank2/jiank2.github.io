N2N: Network Derivative Mining
# Overview
This is a Python implementation for N2N. The package contains the following files:
-- data: data folder
-- eval: folder that contains code files for evaluation
-- load_data.py: python code file to load datasets
-- main.py: demo code file to run the N2N on provided datasets
-- method/hits.py: python code file to construct derivative network for HITS algorithm
-- method/mf.py: python code file to construct derivative network for matrix factorization based collaborative filtering
-- method/sc.py: python code file to construct derivative network for spectral clustering
-- utils.py: python code file for helper functions
-- v0.mat: initial v0 vectors for eigen-decomposition


# Prerequisites
The following packages are needed to run the code in Python 3
-- networkx
-- numpy
-- scipy
-- sklearn


# Usage
Please refer to the demo code file demo.py and the descriptions in each file for the detailed information. The code can be only used for academic purpose and please kindly cite our published paper if you are interested in our work.


# Reference
Kang, Jian and Hanghang Tong. "N2N: Network Derivative Mining." In Proceedings of the 28th ACM International Conference on Information and Knowledge Management, pp. 861-870. 2019.
@inproceedings{kang2019n2n,
  title={N2N: Network Derivative Mining},
  author={Kang, Jian and Tong, Hanghang},
  booktitle={Proceedings of the 28th ACM International Conference on Information and Knowledge Management},
  pages={861–870},
  year={2019}
}
