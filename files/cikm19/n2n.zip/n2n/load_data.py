import os
import networkx as nx


def cit_dblp():
    """
    dblp citation graph
    :return: networkx.DiGraph
    """
    path = os.path.join("data", "cit_dblp")
    graph = nx.read_edgelist(path, create_using=nx.DiGraph(), nodetype=int, data=(('weight', float),))
    return graph


def hamster():
    """
    hamster graph
    :return: networkx.Graph
    """
    path = os.path.join("data", "hamster")
    graph = nx.read_edgelist(path, create_using=nx.Graph(), nodetype=int, data=(('weight', float),))
    return graph


def lastfm():
    """
    lastfm bipartite rating graph
    :return: networkx.Graph
    """
    path = os.path.join("data", "lastfm.dat")
    nusers = 1892
    nitems = 17632
    graph = nx.Graph()
    nodelst = list(range(nusers + nitems))
    graph.add_nodes_from(nodelst)
    with open(path, 'r') as f:
        for line in f:
            data = line.strip().split('\t')
            u = int(data[0])
            v = int(data[1])
            r = int(data[2])
            graph.add_edge(u, v, weight=r)
    return graph, nusers, nitems
