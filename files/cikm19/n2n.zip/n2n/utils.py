import numpy as np


def find_max(mat, is_undirected=False):
    """
    find maximum edge weight in a graph
    :param mat: input graph, scipy.sparse.coo_matrix
    :param is_undirected: boolean indicator of undirected graph
    :return: edge with maximum weight, a tuple of row and column indices
    """
    max_ind = (-1, -1)
    max_val = float('-inf')
    row, col = mat.row, mat.col
    mat = mat.tocsr()
    for i, j in zip(row, col):
        if is_undirected and i > j:
            continue
        if mat[i, j] > max_val:
            max_ind = (i, j)
            max_val = mat[i, j]
    return max_ind


def als(graph, nusers, nitems, nfactors=10, user_regularization=0.5, item_regularization=0.5, maxiter=10, seed=0):
    """
    alternating least squares method
    :param graph: input data, networkx graph
    :param nusers: number of users
    :param nitems: number of items
    :param nfactors: number of latent factors
    :param user_regularization: regularization parameter for user matrix
    :param item_regularization: regularization parameter for item matrix
    :param maxiter: maximum number of iterations
    :param seed: random seed
    :return:
    """
    np.random.seed(seed)

    utu_dict = dict()  # a dict of U(i,:)'U(i,:) for all user i
    vtv_dict = dict()  # a dict of V(j,:)'V(j,:) for all item j
    cinv_dict = dict()  # a dict of inversion of C matrix for each user, see definition of C matrix in the paper
    dinv_dict = dict()  # a dict of inversion of D matrix for each item, see definition of D matrix in the paper

    # initialize factorized U, V matrices
    u = np.random.rand(nusers, nfactors)
    v = np.random.rand(nitems, nfactors)

    user_identity = user_regularization * np.identity(nfactors)
    item_identity = item_regularization * np.identity(nfactors)
    for _ in range(maxiter):
        utu_changed = [False] * nusers
        vtv_changed = [False] * nitems
        # fix item matrix V, train user matrix U
        for i in range(nusers):
            cinv = np.zeros((nfactors, nfactors))  # not inverted yet
            second = np.zeros((1, nfactors))
            for k in graph[i]:
                item_idx = k - nusers
                if (not item_idx in vtv_dict) or (not vtv_changed[item_idx]):
                    vtv_dict[item_idx] = np.outer(v[item_idx, :], v[item_idx, :])
                    vtv_changed[item_idx] = True
                cinv += vtv_dict[item_idx]
                second += (graph[i][k]['weight'] * v[item_idx, :])
            cinv = np.linalg.inv(user_identity + cinv)
            cinv_dict[i] = cinv
            u[i, :] = second @ cinv

        # fix user matrix U, train item matrix V
        for j in range(nitems):
            dinv = np.zeros((nfactors, nfactors))  # not inverted yet
            second = np.zeros((1, nfactors))
            for k in graph[j + nusers]:
                user_idx = k
                if (not user_idx in utu_dict) or (not utu_changed[user_idx]):
                    utu_dict[user_idx] = np.outer(u[user_idx, :], u[user_idx, :])
                    utu_changed[user_idx] = True
                dinv += utu_dict[user_idx]
                second += (graph[k][j + nusers]['weight'] * u[user_idx, :])
            dinv = np.linalg.inv(item_identity + dinv)
            dinv_dict[j] = dinv
            v[j, :] = second @ dinv

    # precomputation for later use
    for i in range(nusers):
        cinv = np.zeros((nfactors, nfactors))  # not inverted yet
        for k in graph[i]:
            item_idx = k - nusers
            vtv_dict[item_idx] = np.outer(v[item_idx, :], v[item_idx, :])
            cinv += vtv_dict[item_idx]
        cinv = np.linalg.inv(user_identity + cinv)
        cinv_dict[i] = cinv
    utu = u.T @ u
    vtv = v.T @ v
    return u, v, utu, vtv, cinv_dict, dinv_dict
