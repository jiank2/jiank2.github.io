import random
import networkx as nx
import scipy.io as sio

import utils
import method.hits
import method.sc
import method.mf
import eval.hits
import eval.sc
import eval.mf

from scipy.sparse.linalg import svds, eigsh

from load_data import *


def main_hits(graph, k):
    """
    main function for HITS
    :param graph: a networkx graph
    :param k: budget
    :return: void
    """
    # get init hub and auth vectors
    adj = nx.to_scipy_sparse_matrix(graph, nodelist=list(range(graph.number_of_nodes())), dtype='d')
    hub, _, auth = svds(adj, k=1)
    hub, auth = hub[:, 0], auth[0, :]

    # demo
    for _ in range(k):
        derivative_network = method.hits.n2n(graph)
        max_edge = utils.find_max(derivative_network, is_undirected=(not graph.is_directed()))
        graph.remove_edge(*max_edge)

    # eval
    error = eval.hits.evaluate(graph, hub, auth)
    print('error:', error)


def main_sc(graph, k, nclusters, v0, seed):
    """
    main function for spectral clustering
    :param graph: a networkx graph
    :param k: budget
    :param nclusters: number of clusters
    :param v0: initial vector for eigen-decomposition
    :param seed: random seed
    :return: void
    """
    # get init eigenvectors
    nnodes = graph.number_of_nodes()
    laplacian = nx.laplacian_matrix(graph, nodelist=list(range(nnodes)))
    _, u = eigsh(laplacian, which='SM', k=nclusters, v0=v0)

    # demo
    for _ in range(k):
        derivative_network = method.sc.n2n(graph)
        max_edge = utils.find_max(derivative_network, is_undirected=True)
        graph.remove_edge(*max_edge)

    # eval
    nmi = eval.sc.evaluate(graph, u, v0=v0, seed=seed)
    print('nmi:', nmi)


def main_mf(graph, k, nusers, nitems, nfactors, user_regularization, item_regularization, maxiter, seed):
    """
    main function for matrix factorization-based collaborative filtering
    :param graph: a networkx graph
    :param k: budget
    :param nusers: number of users
    :param nitems: number of items
    :param nfactors: number of latent factors
    :param user_regularization: regularization parameter for user matrix
    :param item_regularization: regularization parameter for item matrix
    :param maxiter: maximum number of iterations
    :param seed: random seed
    :return: void
    """
    # init
    edgelist = list()

    # get init user and item matrix
    u_orig, v_orig, _, _, _, _ = utils.als(graph, nusers, nitems,
                                           nfactors=nfactors,
                                           user_regularization=user_regularization,
                                           item_regularization=item_regularization,
                                           maxiter=maxiter,
                                           seed=seed)

    # demo
    for _ in range(k):
        derivative_network = method.mf.n2n(graph, nusers, nitems,
                                           nfactors=nfactors,
                                           user_regularization=user_regularization,
                                           item_regularization=item_regularization,
                                           maxiter=maxiter,
                                           seed=seed)
        max_edge = utils.find_max(derivative_network, is_undirected=False)
        max_edge = (max_edge[0], max_edge[1] + nusers)
        edgelist.append(max_edge)
        graph.remove_edge(*max_edge)

    # eval
    rmse = eval.mf.evaluate(graph, edgelist, u_orig, v_orig, nusers, nitems,
                            nfactors=nfactors,
                            user_regularization=user_regularization,
                            item_regularization=item_regularization,
                            maxiter=maxiter,
                            seed=seed)
    print('rmse:', rmse)


if __name__ == '__main__':
    # exp for hits
    k = 50
    graph = cit_dblp()
    main_hits(graph, k)

    # exp for spectral clustering
    k = 50
    nclusters = 5
    seed = random.randint(0, 50)
    v_dict = sio.loadmat('v0.mat')['vDict']
    graph = hamster()
    v0 = v_dict['hamster'][0][0][0]
    main_sc(graph, k, nclusters, v0, seed)

    # exp for matrix factorization-based collaborative filtering
    k = 10
    nfactors = 10
    user_regularization = 0.5
    item_regularization = 0.5
    maxiter = 10
    seed = random.randint(0, 50)
    graph, nusers, nitems = lastfm()
    main_mf(graph, k, nusers, nitems, nfactors, user_regularization, item_regularization, maxiter, seed)
