import utils

from scipy.sparse import coo_matrix


def n2n(graph, nusers, nitems, nfactors=10, user_regularization=0.5, item_regularization=0.5, maxiter=10, seed=0):
    """
    construct derivative network for matrix factorization-based collaborative filtering
    :param graph: input data, networkx.Graph, must be undirected graph
    :param nusers: number of users
    :param nitems: number of items
    :param nfactors: number of latent factors
    :param user_regularization: regularization parameter for user matrix
    :param item_regularization: regularization parameter for item matrix
    :param maxiter: maximum number of iterations
    :param seed: random seed
    :return: derivative network, scipy.sparse.coo_matrix
    """
    row = list()
    col = list()
    data = list()

    u, v, utu, vtv, cinv_dict, dinv_dict = utils.als(graph, nusers, nitems,
                                                     nfactors=nfactors,
                                                     user_regularization=user_regularization,
                                                     item_regularization=item_regularization,
                                                     maxiter=maxiter,
                                                     seed=seed)
    for e in graph.edges():
        i = min(e[0], e[1])
        j = max(e[0] - nusers, e[1] - nusers)
        derivative = 2 * (u[i, :] @ vtv @ cinv_dict[i] @ v[j, :].T + v[j, :] @ utu @ dinv_dict[j] @ u[i, :].T)
        row.append(i)
        col.append(j)
        data.append(derivative)
    derivative_network = coo_matrix((data, (row, col)), shape=(nusers, nitems))
    return derivative_network
