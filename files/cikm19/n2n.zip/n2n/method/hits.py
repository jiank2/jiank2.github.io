import networkx as nx
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import svds


def n2n(graph):
    """
    construct derivative network for HITS
    :param graph: input data, networkx graph
    :return: derivative network, scipy.sparse.coo_matrix
    """
    row = list()
    col = list()
    data = list()
    nnodes = graph.number_of_nodes()
    adj = nx.to_scipy_sparse_matrix(graph, nodelist=list(range(nnodes)), dtype='d')
    u, s, v = svds(adj, k=2)
    for e in graph.edges():
        i, j = e[0], e[1]
        if nx.is_directed(graph):
            derivative = s[1] * u[i, 1] * v[1, j] - s[0] * u[i, 0] * v[0, j]
            row.append(i)
            col.append(j)
            data.append(derivative)
        else:
            if i != j:
                derivative = s[1] * u[i, 1] * v[1, j] - s[0] * u[i, 0] * v[0, j] \
                             + s[1] * u[j, 1] * v[1, i] - s[0] * u[j, 0] * v[0, i]
            else:
                derivative = s[1] * u[i, 1] * v[1, j] - s[0] * u[i, 0] * v[0, j]
            row.append(i)
            row.append(j)
            col.append(j)
            col.append(i)
            data.append(derivative)
            data.append(derivative)
    derivative_network = coo_matrix((data, (row, col)), shape=(nnodes, nnodes))
    return derivative_network
