import networkx as nx
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh


def n2n(graph, nclusters=5, v0=None):
    """
    construct derivative network for spectral clustering
    :param graph: input data, networkx.Graph, must be undirected graph
    :param nclusters: number of clusters
    :param v0: initial vector for eigen-decomposition
    :return: derivative network, scipy.sparse.coo_matrix
    """
    row = list()
    col = list()
    data = list()
    nnodes = graph.number_of_nodes()
    laplacian = nx.laplacian_matrix(graph, nodelist=list(range(nnodes)))
    _, u = eigsh(laplacian, which='SM', k=nclusters, v0=v0)
    for e in graph.edges():
        i, j = e[0], e[1]
        derivative = (u[i, :] @ u[i, :].T) + (u[j, :] @ u[j, :].T) - (u[j, :] @ u[i, :].T) - (u[i, :] @ u[j, :].T)
        row.append(i)
        row.append(j)
        col.append(j)
        col.append(i)
        data.append(derivative)
        data.append(derivative)
    derivative_network = coo_matrix((data, (row, col)), shape=(nnodes, nnodes))
    return derivative_network
