import numpy as np
import networkx as nx

from scipy.sparse.linalg import svds


def evaluate(graph, hub, auth):
    """
    evaluate effectiveness for HITS
    :param graph: perturbed graph, networkx graph
    :param hub: original hub vector
    :param auth: original authority vector
    :return: residual defined in the paper
    """
    # HITS by SVD
    adj = nx.to_scipy_sparse_matrix(graph, nodelist=list(range(graph.number_of_nodes())), dtype='d')
    hub_tilde, _, auth_tilde = svds(adj, k=1)
    hub_tilde, auth_tilde = hub_tilde[:, 0], auth_tilde[0, :]

    # calculate error
    residual_hub = np.linalg.norm(np.absolute(hub) - np.absolute(hub_tilde), ord=2)
    residual_auth = np.linalg.norm(np.absolute(auth) - np.absolute(auth_tilde), ord=2)
    return residual_hub + residual_auth
