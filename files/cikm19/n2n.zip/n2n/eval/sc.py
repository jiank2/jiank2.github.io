import networkx as nx

from scipy.sparse.linalg import eigsh
from sklearn.cluster import KMeans
from sklearn.metrics import normalized_mutual_info_score


def evaluate(graph, u, v0=None, seed=0):
    """
    evaluate effectiveness for spectral clustering
    :param graph: perturbed graph, networkx.Graph, must be undirected
    :param u: original eigenvectors
    :param v0: initial vector for eigen-decomposition
    :param seed: random seed
    :return: normalized mutual information
    """
    # get original clustering membership
    kmeans = KMeans(n_clusters=u.shape[1], random_state=seed).fit(u)
    labels_orig = kmeans.labels_

    # get clustering membership for perturbed graph
    nnodes = graph.number_of_nodes()
    laplacian = nx.laplacian_matrix(graph, nodelist=list(range(nnodes)))
    _, u_tilde = eigsh(laplacian, which='SM', k=u.shape[1], v0=v0)
    kmeans_tilde = KMeans(n_clusters=u_tilde.shape[1], random_state=seed).fit(u_tilde)
    labels_perturbed = kmeans_tilde.labels_

    # calculate normalized mutual information
    nmi = normalized_mutual_info_score(labels_orig, labels_perturbed, average_method='geometric')
    return nmi
