import numpy as np

import utils


def evaluate(graph, edgelist, u_orig, v_orig, nusers, nitems, nfactors=10, user_regularization=0.5, item_regularization=0.5, maxiter=10, seed=0):
    """
    evaluate effectiveness for matrix factorization-based collaborative filtering
    :param graph: input data, networkx.Graph, must be undirected graph
    :param edgelist: list of removed ratings
    :param u_orig: original user matrix
    :param v_orig: original item matrix
    :param nusers: number of users
    :param nitems: number of items
    :param nfactors: number of latent factors
    :param user_regularization: regularization parameter for user matrix
    :param item_regularization: regularization parameter for item matrix
    :param maxiter: maximum number of iterations
    :param seed: random seed
    :return: RMSE
    """
    # matrix factorization by alternating least squares
    u_tilde, v_tilde, _, _, _, _ = utils.als(graph, nusers, nitems,
                                             nfactors=nfactors,
                                             user_regularization=user_regularization,
                                             item_regularization=item_regularization,
                                             maxiter=maxiter,
                                             seed=seed)
    # calculate RMSE
    rmse = 0
    cnt = 0
    for i in range(nusers):
        for j in range(nitems):
            if not ((i, j+nusers) in edgelist) and not (j+nusers in graph[i]):
                rmse += ((u_orig[i, :] @ v_orig[j, :].T) - (u_tilde[i, :] @ v_tilde[j, :].T)) ** 2
                cnt += 1
    rmse /= cnt
    rmse = np.sqrt(rmse)
    return rmse
